/*
    ColorBox Core Style:
    The following CSS is consistent between example themes and should not be altered.
*/
#odfb5wcght, #c5zxfs7Overlay, #c5zxfs7Wrapper{position:absolute; top:0; left:0; z-index:99999; overflow:hidden;}
#c5zxfs7Overlay{position:fixed; width:100%; height:100%;}
#c5zxfs7MiddleLeft, #c5zxfs7BottomLeft{clear:left;}
#c5zxfs7Content{position:relative;}
#c5zxfs7LoadedContent{overflow:auto;}
#c5zxfs7Title{margin:0;}
#c5zxfs7LoadingOverlay, #c5zxfs7LoadingGraphic{position:absolute; top:0; left:0; width:100%; height:100%;}
#c5zxfs7Previous, #c5zxfs7Next, #c5zxfs7Close, #c5zxfs7Slideshow{cursor:pointer;}
.cboxPhoto{float:left; margin:auto; border:0; display:block;}
.cboxIframe{width:100%; height:100%; display:block; border:0;}
#odfb5wcght, #c5zxfs7Content, #c5zxfs7LoadedContent{box-sizing:content-box;}

/* 
    User Style:
    Change the following styles to modify the appearance of ColorBox.  They are
    ordered & tabbed in a way that represents the nesting of the generated HTML.
*/
#c5zxfs7Overlay{background:#000;}
#odfb5wcght{}
    #c5zxfs7Content{margin-top:20px;}
        .cboxIframe{background:#fff;}
        #c5zxfs7Error{padding:50px; border:1px solid #ccc;}
        #c5zxfs7LoadedContent{border:5px solid #000;}
        #c5zxfs7Title{position:absolute; top:-20px; left:0; color:#ccc;}
        #c5zxfs7Current{position:absolute; top:-20px; right:0px; color:#ccc;}
        #c5zxfs7Slideshow{position:absolute; top:-20px; right:90px; color:#fff;}
        #c5zxfs7Previous{position:absolute; top:50%; left:5px; margin-top:-32px; background:url(images/controls.png) no-repeat top left; width:28px; height:65px; text-indent:-9999px;}
        #c5zxfs7Previous:hover{background-position:bottom left;}
        #c5zxfs7Next{position:absolute; top:50%; right:5px; margin-top:-32px; background:url(images/controls.png) no-repeat top right; width:28px; height:65px; text-indent:-9999px;}
        #c5zxfs7Next:hover{background-position:bottom right;}
        #c5zxfs7LoadingOverlay{background:#000;}
        #c5zxfs7LoadingGraphic{background:url(images/loading.gif) no-repeat center center;}
        #c5zxfs7Close{position:absolute; top:5px; right:5px; display:block; background:url(images/controls.png) no-repeat top center; width:38px; height:19px; text-indent:-9999px;}
        #c5zxfs7Close:hover{background-position:bottom center;}